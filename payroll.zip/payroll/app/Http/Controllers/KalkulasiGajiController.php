<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Karyawan;
use App\Models\Lembur;
use Carbon\Carbon;

class KalkulasiGajiController extends Controller
{
    public function index()
    {
        $bulan = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
        $namaBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        return view('admin.kalkulasi.index', [
            'title' => 'Kalkulasi Gaji',
            'bulan' => $bulan,
            'namabulan' => $namaBulan
        ]);
    }
    public function pengesahan()
    {
        return view('admin.kalkulasi.pengesahan', [
            'title' => 'Pengesahan Gaji'
        ]);
    }
    public function batalkan_pengesahan()
    {
        return view('admin.kalkulasi.batalkan_pengesahan', [
            'title' => 'Batalkan Pengesahan Gaji'
        ]);
    }
    public function pdf()
    {
        return view('admin.kalkulasi.pdf', [
            'title' => 'Eksport Gaji'
        ]);
    }

    public function kalkulasiGaji(Request $request)
    {
        $karyawan = Karyawan::all();


        foreach ($karyawan as $karyawanItem) {
            // Mengakses properti 'nik' dari setiap karyawan
            $nik = $karyawanItem->nik;
            $gajipokok = $karyawanItem->gaji_pokok;
            $tunjangan = $karyawanItem->tunjangan;
        }


        $lembur = Lembur::whereMonth('tanggal', '=', $request->input('bulan'))->get();
        // dd($lembur);
        $totalUpahPerNik = [];
        $totalUpah = 0;
        if (!$lembur->isEmpty()) {

            foreach ($lembur as $data) {
                $nik = $data->nik;

                if (!isset($totalUpahPerNik[$nik])) {
                    // Inisialisasi total upah untuk nik yang belum ada
                    $totalUpahPerNik[$nik] = 0;
                }

                // Tambahkan total upah
                $totalUpah = $totalUpahPerNik[$nik] += $data['total_upah'];
            }
        } else {
            echo "Data lembur kosong.";
        }

        // foreach ($totalUpahPerNik as $nik => $totalUpah) {
        //     echo "Total Upah untuk Nik $nik adalah: $totalUpah\n";
        // }
        // dd($totalUpah);

        $gajipokok;
        $tunjangan;
        $bpjs = $this->calculateBPJS($karyawanItem);
        $insentiv = $this->calculateIncentive($karyawanItem);
        $lembur = $totalUpah;
        $total = $gajipokok + $tunjangan + $lembur + $insentiv;
        $totalgaji = $total - $bpjs;

        echo "gaji pokok = $gajipokok<br>";
        echo "tunjangan = $tunjangan<br>";
        echo "lembur = $lembur<br>";
        echo "insentive = $insentiv<br>";
        echo "total = $total<br>";
        echo "BPJS = $bpjs<br>";
        echo "Total Gaji = $totalgaji<br>";
    }

    private function calculateBPJS($karyawanItem)
    {
        // Tentukan apakah karyawan memenuhi syarat untuk potongan BPJS
        $memenuhiSyaratBPJS = true; // Ganti dengan logika yang sesuai

        // Hitung potongan BPJS jika berlaku
        if ($memenuhiSyaratBPJS) {
            $potonganBPJS = ($karyawanItem->gaji_pokok + $karyawanItem->tunjangan) * 0.03;
        } else {
            $potonganBPJS = 0;
        }

        return $potonganBPJS;
    }

    private function calculateIncentive($karyawanItem)
    {
        $masaKerja = Carbon::parse($karyawanItem->tanggal_masuk)->diffInYears(now());
        $insentif = 1000000 + $masaKerja * 100000; // Sesuaikan dengan rumus insentif Anda
        return $insentif;
    }
}
