
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="bg-light rounded p-4">
        <h6 class="mb-0"><?php echo e(($title)); ?></h6>
        <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="my-3 col-12 col-sm-8 col-md-5">
                    <form action="" method="get">                    
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" id="floatingInputGroup1" placeholder="Input Kode Transaksi" name="keywoard" value="<?php echo e(request('search')); ?>">
                            <button type="submit" class="input-group-text btn btn-primary">Search</button>
                            <a href="/karyawan/create" class="btn btn-primary m-1">Tambah Data </a>
                        </div>
                    </form>
                </div>
            
        </div>
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

       
        <div class="table-responsive">
            <table class="table text-start align-middle table-bordered table-hover mb-0">
                <thead>
                    <tr class="text-dark">
                        
                        <th scope="col" width="5%">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Nik</th>
                        <th scope="col">Tempat Lahir</th>
                        <th scope="col">Tanggal Lahir</th>
                        
                        
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datakaryawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(($datakaryawan->nama)); ?></td>
                        <td><?php echo e(($datakaryawan->nik)); ?></td>
                        <td><?php echo e(($datakaryawan->tempat_lahir)); ?></td>                            
                        <td><?php echo e(($datakaryawan->tanggal_lahir)); ?></td>                            
                        
                        <td>
                        
                            
                            <a class="btn btn-sm btn-warning" href="/karyawan/<?php echo e($datakaryawan->id); ?>/edit">Edit</a>
                            <form action="<?php echo e(route('karyawan.destroy', $datakaryawan->id)); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
      

        <div class=" my-5 d-flex justify-content-center">
            
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\payroll\resources\views/admin/karyawan/index.blade.php ENDPATH**/ ?>