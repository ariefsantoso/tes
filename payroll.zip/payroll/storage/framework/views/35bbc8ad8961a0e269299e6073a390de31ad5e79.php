
<?php $__env->startSection('content'); ?>
     <!-- Sale & Revenue Start -->
     <div class="container-fluid pt-4 px-4">
         <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Welcome Back, <?php echo e(auth()->user()->name); ?></h1>
         </div>
    </div>
    <!-- Sale & Revenue End -->


    <!-- Sales Chart Start -->
  
    <!-- Sales Chart End -->


    <!-- Recent Sales Start -->
   
    <!-- Recent Sales End -->


    <!-- Widgets Start -->
  
    <!-- Widgets End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\payroll\resources\views/admin/index.blade.php ENDPATH**/ ?>