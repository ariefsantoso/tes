

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="d-flex align-items-center justify-content-between mb-4">
        <h6 class="mb-0"><?php echo e(($title)); ?></h6>
        
    </div>

    <form action="<?php echo e(route('absen.update', $absen->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div id="form-container">
            
            
            
            <div class="mb-3 row">
                <label for="nik" class="col-sm-2 col-form-label">NIK</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nik" id="nik" placeholder="Masukkan Tanggal Masuk" value="<?php echo e($absen->nik); ?>" readonly>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="keterangan" class="col-sm-2 col-form-label">Keterangan</label>
                <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example" name="keterangan" id="keterangan">
                        <option value="<?php echo e($absen->keterangan); ?>" disabled selected><?php echo e($absen->keterangan); ?></option>
                        <option value="Cuti Resmi">Cuti Resmi</option>
                        <option value="Izin">Izin</option>
                        <option value="Sakit">Sakit</option>
                        <option value="Alpha">Alpha</option>
                    </select>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                <div class="col-sm-10">
                  <input type="date" class="form-control" name="tanggal" id="tanggal" placeholder="Masukkan Tanggal Masuk" value="<?php echo e($absen->tanggal); ?>">
                </div>
            </div>
            <input type="hidden" class="form-control" name="bulan" id="bulan" placeholder="Masukkan bulan" value="<?php echo e($absen->bulan); ?>">
        </div>
        <br>
        <br>
        <div class="col-auto">
           
            
            <div class="mb-3">
                <input type="submit" value="Simpan" class="btn btn-primary mb-3">
            </div>
        </div>
        <br>
        
    </form>
    <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\payroll\resources\views/admin/cuti/edit.blade.php ENDPATH**/ ?>