
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="bg-light rounded p-4">
        <h6 class="mb-0"><?php echo e(($title)); ?></h6>
        <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="my-3 col-12 col-sm-8 col-md-5">
                    <form action="" method="get">                    
                        <div class="input-group mb-3">
                           
                            
                        </div>
                    </form>
                </div>
            
        </div>
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

       
    <form action="<?php echo e(route('lembur.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div id="form-container">
            
            
            <div class="mb-3 row">
                <label for="bulan" class="col-sm-2 col-form-label">Pilih Bulan</label>
                <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example" name="bulan" id="bulan">
                            <option value="1">Januari</option>
                            <option value="2">Februari</option>
                            <option value="3">Maret</option>
                            <option value="4">April</option>
                            <option value="5">Mei</option>
                            <option value="6">Juni</option>
                            <option value="7">Juli</option>
                            <option value="8">Agustus</option>
                            <option value="9">September</option>
                            <option value="10">Oktober</option>
                            <option value="11">November</option>
                            <option value="12">Desember</option>
                    </select>
                </div>
            </div>
           
           
        
        <br>
        <div class="col-auto">
           
            
            <div class="mb-3">
                <input type="submit" value="Kalkulasi" class="btn btn-primary mb-3">
            </div>
        </div>
        <br>
        
    </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\payroll\resources\views/admin/kalkulasi/pdf.blade.php ENDPATH**/ ?>